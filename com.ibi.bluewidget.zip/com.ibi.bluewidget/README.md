
#### Extension from WebFocus 8200

# Bluewidget

For installation instructions please visit this [link] (https://github.com/ibi/wf-extensions-chart/wiki/Installing-a-WebFocus-Extension "Installing a WebFocus Extension").

## Description

This extension displays the value of the KPI, a related icon and if variation is required with respect to a comparison value.

## Screenshots
![screenshot_1] (https://github.com/JK12400/WF-Extentions/blob/master/com.ibi.bluewidget/icons/bluewidget_icon.PNG)
![screenshot_2] (https://github.com/JK12400/WF-Extentions/blob/master/com.ibi.bluewidget/icons/bluewidget_icon2.PNG)

## Configurations

To configure or customize your extension edit "properties" object in properties.json file.

**Any property can be overwritten from a property that is written in the webfocus chart code (GRAPH_JS_FINAL Properties) or in the STY file**
	
	"properties": {
	
		"kpiboxProperties": {   
			"ibiAppsPath": "/ibi_apps/",	
			"calculateComparationFunction": {
				"param1": "valueKpi", 
				"param2": "compareValue", 
				"body": "if(valueKpi == 0 && compareValue == 0) { return 0; } var result = (valueKpi - compareValue) / Math.abs(compareValue);  return result;"
			},	
			"formatComparation": "#,###.00%",
			"customCompareIcon": {
				"active": false,	
				"iconUp": "",
				"iconDown": "",
			},
			"shortenNumber": true, 
			"typeShortenNumber": null, // "long scale" (default)/ "short scale"
										// "long scale": K: 10^3, M: 10^6, B: 10^9, T: 10^12
										// "short scale": K: 10^3, M: 10^6, B: 10^12
			"setInfiniteToZero": false,
			"titleRow": false,
			"calculateFontSize": false, 
			"fixedFontSizeProp": "18px",
			"fixedPixelLinesMargin": 20,
			"imagePercentageWidth": 40,
			"titleFont": {
				"size": "18px",
				"color": "black",
				"family": "Arial, sans-serif"
			},
			"measureFont": {
				"size": "18px",
				"color": "black",
				"family": "Arial, sans-serif"
			},
			"variationFont": {
				"size": "18px",
				"family": "Arial, sans-serif"
			},
			"bodyBackgroundColor": "transparent"
		},
		"colorScale": {
			"colorMode":"discrete",
			"colorBands": [
				{"start": -1000000000000, "stop": 0, "color":"red"},
				{"start": 0, "stop": 1000000000000, "color":"green"}
			]
		}
		
	},
	 
	"propertyAnnotations": {
	
		"kpiboxProperties": "json",		
		"colorScale": "json"
		
	}


## Data Buckets

### Measures:
* **Value Bucket (1, required; 1, Optional)** - Required. KPI value
* **Compare Value Bucket (1, non required)** - Not required. KPI for comparison.
* **Sign Comparision Bucket (1, non required)** - Not required. Positive or negative value to set comparision direction.

### Dimensions
* **Image Bucket (1, non required)** - Not required. Reference the Approot path of an image.
* **Compareicon Bucket (1, not required)** - Not required. Reference the Approot path of an image.
* **FooterTxt Bucket (1, not required)** - Not required. Support text to be appended to the Percentage Compare Value
 
